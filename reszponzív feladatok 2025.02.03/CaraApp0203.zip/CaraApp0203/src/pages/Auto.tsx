import { useEffect, useState } from 'react';
import apiClient from '../api/apiClient';
import { Car } from '../types/Car';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
const Auto = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [data, setData] = useState<Car>();
    useEffect(() => {
        apiClient.get(`/cars/${id}`).then((res) => {
            setData(res.data);
        });
    });
    const DeleteCar = async () => {
        const response = await apiClient.delete(`/cars/${id}`);
        switch (response.status) {
            case 200:
                toast('Auto sikeresem törölve!', {
                    theme: 'colored',
                    type: 'success',
                });
                navigate('/autok');
                break;
            case 404:
                toast('Nem található ilyen autó!', {
                    theme: 'colored',
                    type: 'warning',
                });
                break;
            default:
                toast('Hiba a törlés közben!', {
                    theme: 'colored',
                    type: 'error',
                });
        }
    };
    return (
        <>
            <div className="navbar">
                <button className="Inaktiv" onClick={() => navigate('/autok')}>
                    Autók
                </button>
                <button className="Inaktiv" onClick={() => navigate('/ujauto')}>
                    Új autó hozzáadása
                </button>
                <button className="Inaktiv" onClick={() => navigate('/autoszerk')}>
                    Autó szerkesztése
                </button>
            </div>

            {data ? (
                <div>
                    <h1>{data.brand + ' ' + data.model}</h1>
                    <table className="AutoTable">
                        <tr>
                            <th>Id</th>
                            <td>{data.id}</td>
                        </tr>
                        <tr>
                            <th>Márka</th>
                            <td>{data.brand}</td>
                        </tr>
                        <tr>
                            <th>Modell</th>
                            <td>{data.model}</td>
                        </tr>
                        <tr>
                            <th>Évjárat</th>
                            <td>{data.year}</td>
                        </tr>
                        <tr>
                            <td colSpan={2}>
                                <button className="DeleteButton" onClick={DeleteCar}>
                                    Törlés
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td colSpan={2}>
                                <button className="BackButton" onClick={() => navigate('/autok')}>
                                    Vissza
                                </button>
                            </td>
                        </tr>
                    </table>
                </div>
            ) : (
                <p>Nincs ilyen autó!</p>
            )}
        </>
    );
};
export default Auto;

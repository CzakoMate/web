import { useEffect, useState } from 'react';
import apiClient from '../api/apiClient';
import { Car } from '../types/Car';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
const UjAuto = () => {
    const navigate = useNavigate();
    const [brand, setBrand] = useState<string>('');
    const [model, setModel] = useState<string>('');
    const [year, setYear] = useState<number>(0);
    const PostCar = async () => {
        const car = {
            brand: brand,
            model: model,
            year: year,
        };
        const response = await apiClient.post('/cars', car);
        switch (response.status) {
            case 201:
                toast('Autó sikeresen hozzáadva!', {
                    theme: 'colored',
                    type: 'success',
                });
                navigate('/autok');
                break;
            case 409:
                toast('Már van ilyen autó!', {
                    theme: 'colored',
                    type: 'warning',
                });
                break;
            case 404:
                toast('Nem található ilyen autó!', {
                    theme: 'colored',
                    type: 'warning',
                });
                break;
            default:
                toast('Hiba a hozzáadás közben!', {
                    theme: 'colored',
                    type: 'error',
                });
        }
    };
    return (
        <>
            <div className="navbar">
                <button className="Inaktiv" onClick={() => navigate('/autok')}>
                    Autók
                </button>
                <button className="Aktiv">Új autó hozzáadása</button>
                <button className="Inaktiv" onClick={() => navigate('/autoszerk')}>
                    Autó szerkesztése
                </button>
            </div>

            <h1>Új auto hozzáadása</h1>
            <table>
                <tbody>
                    <tr>
                        <th>Márka</th>
                        <td>
                            <input
                                type="text"
                                onChange={(e) => setBrand(e.target.value)}
                                placeholder="Új márka"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th>Modell</th>
                        <td>
                            <input
                                type="text"
                                onChange={(e) => setModel(e.target.value)}
                                placeholder="Új modell"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th>Évjárat</th>
                        <td>
                            <input
                                type="number"
                                min={1900}
                                onChange={(e) => setYear(Number(e.target.value))}
                                placeholder="Új évjárat"
                            />
                        </td>
                    </tr>
                    <tr>
                        <td colSpan={2}>
                            <button className="ViewButton" onClick={PostCar}>
                                Hozzáadás
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </>
    );
};
export default UjAuto;

import { useEffect, useState } from 'react';
import apiClient from '../api/apiClient';
import { Car } from '../types/Car';
import { useNavigate } from 'react-router-dom';
const Autok = () => {
    const navigate = useNavigate();
    const [data, setData] = useState<Array<Car>>();
    useEffect(() => {
        apiClient.get('/cars').then((res) => {
            setData(res.data);
        });
    });
    return (
        <>
            <div className="navbar">
                <button className="Aktiv">Autók</button>
                <button className="Inaktiv" onClick={() => navigate('/ujauto')}>
                    Új autó hozzáadása
                </button>
                <button className="Inaktiv" onClick={() => navigate('/autoszerk')}>
                    Autó szerkesztése
                </button>
            </div>

            <h1>Autok</h1>
            <table>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Márka</th>
                        <th>Modell</th>
                        <th>Évjárat</th>
                        <th>Megtekintés</th>
                    </tr>
                </thead>
                <tbody>
                    {data?.map((i: Car) => (
                        <tr key={i.id}>
                            <td>{i.id}</td>
                            <td>{i.brand}</td>
                            <td>{i.model}</td>
                            <td>{i.year}</td>
                            <td>
                                <button
                                    className="ViewButton"
                                    onClick={() => navigate(`/autok/${i.id}`)}
                                >
                                    Megtekintés
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </>
    );
};
export default Autok;

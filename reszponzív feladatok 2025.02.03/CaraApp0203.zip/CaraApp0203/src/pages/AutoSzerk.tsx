import { useEffect, useState } from 'react';
import apiClient from '../api/apiClient';
import { Car } from '../types/Car';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const AutoSzerk = () => {
    const navigate = useNavigate();
    const [data, setData] = useState<Array<Car>>([]);
    const [brand, setBrand] = useState<string>('');
    const [model, setModel] = useState<string>('');
    const [year, setYear] = useState<number>(0);
    const [content, setContent] = useState<Car | null>(null);
    const [car, setCar] = useState<string>('1');

    useEffect(() => {
        apiClient.get('/cars').then((res) => {
            setData(res.data);
        });
    }, []);

    const updateCar = async () => {
        const updatedCar = {
            brand: brand,
            model: model,
            year: year,
        };
        const response = await apiClient.put(`/cars/${content?.id}`, updatedCar);
        switch (response.status) {
            case 201:
                toast('Sikeres autó frissítés!', {
                    theme: 'colored',
                    type: 'success',
                });
                window.location.reload();
                break;
            case 404:
                toast('Nem található ilyen autó!', {
                    theme: 'colored',
                    type: 'warning',
                });
                break;
            default:
                toast('Hiba a frissítés közben!', {
                    theme: 'colored',
                    type: 'error',
                });
        }
    };

    useEffect(() => {
        const selectedId = parseInt(car, 10);
        const selectedItem = data.find((car) => car.id === selectedId);
        setContent(selectedItem || null);
        if (selectedItem) {
            setBrand(selectedItem.brand);
            setModel(selectedItem.model);
            setYear(selectedItem.year);
        }
    }, [car, data]);

    return (
        <>
            <div className="navbar">
                <button className="Inaktiv" onClick={() => navigate('/autok')}>
                    Autók
                </button>
                <button className="Inaktiv" onClick={() => navigate('/ujauto')}>
                    Új autó hozzáadása
                </button>
                <button className="Aktiv">Autó szerkesztése</button>
            </div>

            <h1>Auto szerkesztése</h1>
            <select name="Autok" onChange={(e) => setCar(e.target.value)}>
                <option value="">Select a car</option>
                {data.map((i: Car) => (
                    <option key={i.id} value={i.id.toString()}>
                        {i.brand + ' ' + i.model}
                    </option>
                ))}
            </select>
            <table>
                <tbody>
                    <tr>
                        <th>Márka</th>
                        <td>
                            <input
                                type="text"
                                value={brand}
                                onChange={(e) => setBrand(e.target.value)}
                                placeholder="Új márka"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th>Modell</th>
                        <td>
                            <input
                                type="text"
                                value={model}
                                onChange={(e) => setModel(e.target.value)}
                                placeholder="Új modell"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th>Évjárat</th>
                        <td>
                            <input
                                type="number"
                                value={year}
                                onChange={(e) => setYear(Number(e.target.value))}
                                placeholder="Új évjárat"
                            />
                        </td>
                    </tr>
                    <tr>
                        <td colSpan={2}>
                            <button className="ViewButton" onClick={updateCar}>
                                Mentés
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </>
    );
};

export default AutoSzerk;

import React from 'react';
import ReactDOM from 'react-dom/client';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Autok from './pages/Autok';
import Auto from './pages/Auto';
import AutoSzerk from './pages/AutoSzerk';
import UjAuto from './pages/UjAuto';
import './styles/style.css';
import { ToastContainer } from 'react-toastify';
const root = ReactDOM.createRoot(document.getElementById('root') as HTMLElement);
root.render(
    <React.StrictMode>
        <BrowserRouter>
            <Routes>
                <Route path="/autok" element={<Autok />} />
                <Route path="/autok/:id" element={<Auto />} />
                <Route path="/autoszerk" element={<AutoSzerk />} />
                <Route path="/ujauto" element={<UjAuto />} />
                <Route path="*" element={<h1>404 - Az oldal nem található</h1>} />
            </Routes>
        </BrowserRouter>
        <ToastContainer />
    </React.StrictMode>,
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

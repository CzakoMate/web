export type Car = {
    id: number;
    model: string;
    brand: string;
    year: number;
};

import swaggerAutogen from "swagger-autogen";
const doc = {
  info: {
    title: "Product API",
    version: "1.0.0",
    description: "Planters API",
  },
  host: "localhost:3000",
  basePath: "/api/plants",
};
const outputFile = "./swagger-output.json";
const routes = ["./routes/plants.js"];
swaggerAutogen()(outputFile, routes, doc);
import express from "express";
import { dbQuerry, dbRun } from "../database.js";
const router = express.Router();

router.get("/", async (req, res, next) => {
  try {
    const plants = await dbQuerry("SELECT * FROM plants;");
    res.status(200).json(plants);
  } catch (err) {
    next(err);
  }
});
router.get("/:id", async (req, res, next) => {
  try {
    const [plant] = await dbQuerry("SELECT * FROM plants WHERE id=?;", [
      req.params.id,
    ]);
    if (!plant) return res.status(404).json({ message: "Plant not found" });
    res.status(200).json(plant);
  } catch (err) {
    next(err);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const result = await dbRun(
      "INSERT INTO plants (nev, evelo_e, kategoria, ar) VALUES(?,?,?,?);",
      [req.body.nev, req.body.evelo_e, req.body.kategoria, req.body.ar]
    );
    res.status(201).json({ id: result.lastID, ...req.body });
  } catch (err) {
    next(err);
  }
});

router.put("/:id", async (req, res, next) => {
  try {
    const [plant] = await dbQuerry("SELECT * FROM plants WHERE id=?;", [
      req.params.id,
    ]);
    if (!plant) return res.status(404).json({ message: "Plant not found" });
    await dbRun(
      "UPDATE plants SET nev=?, evelo_e=?, kategoria=?, ar=? WHERE id=?;",
      [
        req.body.nev || plant.nev,
        req.body.evelo_e || plant.evelo_e,
        req.body.kategoria || plant.kategoria,
        req.body.ar || plant.ar,
        req.params.id,
      ]
    );
    res.status(200).json({ id: req.params.id, ...req.body });
  } catch (err) {
    next(err);
  }
});
router.delete("/:id", async (req, res, next) => {
  try {
    const [plant] = await dbQuerry("SELECT * FROM plants WHERE id=?;", [
      req.params.id,
    ]);
    if (!plant) return res.status(404).json({ message: "Plant not found" });
    await dbRun("DELETE FROM plants WHERE id=?;", [req.params.id]);
    res.sendStatus(204);
  } catch (err) {
    next(err);
  }
});

export default router;
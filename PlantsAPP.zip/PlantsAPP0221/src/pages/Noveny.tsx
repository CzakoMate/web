import { useEffect, useState } from 'react';
import apiClient from '../api/apiClient';
import { Plant } from '../types/Plant';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
const Noveny = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [data, setData] = useState<Plant>();
    useEffect(() => {
        apiClient.get(`/plants/${id}`).then((res) => {
            setData(res.data);
        });
    });
    const DeletePlant = async () => {
        const response = await apiClient.delete(`/plants/${id}`);
        switch (response.status) {
            case 204:
                toast('Növény sikeresen törölve!', {
                    theme: 'colored',
                    type: 'success',
                });
                navigate('/novenyek');
                break;
            case 404:
                toast('Nem található ilyen növény!', {
                    theme: 'colored',
                    type: 'warning',
                });
                break;
            default:
                toast('Hiba a törlés közben!', {
                    theme: 'colored',
                    type: 'error',
                });
        }
    };
    return (
        <>
            <div className="navbar">
                <button className="Inaktiv" onClick={() => navigate('/novenyek')}>
                    Növények
                </button>
                <button className="Inaktiv" onClick={() => navigate('/ujnoveny')}>
                    Új növény hozzáadása
                </button>
                <button className="Inaktiv" onClick={() => navigate('/novenyszerk')}>
                    Növény szerkesztése
                </button>
            </div>

            {data ? (
                <div>
                    <h1>{data.nev}</h1>
                    <table className="NovenyTable">
                        <tr>
                            <th>Id</th>
                            <td>{data.id}</td>
                        </tr>
                        <tr>
                            <th>Név</th>
                            <td>{data.nev}</td>
                        </tr>
                        <tr>
                            <th>Évelő-e</th>
                            <td>{data.evelo_e}</td>
                        </tr>
                        <tr>
                            <th>Kategória</th>
                            <td>{data.kategoria}</td>
                        </tr>
                        <tr>
                            <th>Ár</th>
                            <td>{data.ar}</td>
                        </tr>
                        <tr>
                            <td colSpan={2}>
                                <button className="DeleteButton" onClick={DeletePlant}>
                                    Törlés
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td colSpan={2}>
                                <button
                                    className="BackButton"
                                    onClick={() => navigate('/novenyek')}
                                >
                                    Vissza
                                </button>
                            </td>
                        </tr>
                    </table>
                </div>
            ) : (
                <p>Nincs ilyen növény!</p>
            )}
        </>
    );
};
export default Noveny;

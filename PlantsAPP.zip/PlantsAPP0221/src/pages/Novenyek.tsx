import { useEffect, useState } from 'react';
import apiClient from '../api/apiClient';
import { Plant } from '../types/Plant';
import { useNavigate } from 'react-router-dom';
const Novenyek = () => {
    const navigate = useNavigate();
    const [data, setData] = useState<Array<Plant>>();
    useEffect(() => {
        apiClient.get('/plants').then((res) => {
            setData(res.data);
        });
    });
    return (
        <>
            <div className="navbar">
                <button className="Aktiv">Növények</button>
                <button className="Inaktiv" onClick={() => navigate('/ujnoveny')}>
                    Új növény hozzáadása
                </button>
                <button className="Inaktiv" onClick={() => navigate('/novenyszerk')}>
                    Növény szerkesztése
                </button>
            </div>

            <h1>Növények</h1>
            <table>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Név</th>
                        <th>Évelő-e</th>
                        <th>Kategória</th>
                        <th>Ár</th>
                        <th>Megtekintés</th>
                    </tr>
                </thead>
                <tbody>
                    {data?.map((i: Plant) => (
                        <tr key={i.id}>
                            <td>{i.id}</td>
                            <td>{i.nev}</td>
                            <td>{i.evelo_e}</td>
                            <td>{i.kategoria}</td>
                            <td>{i.ar}</td>
                            <td>
                                <button
                                    className="ViewButton"
                                    onClick={() => navigate(`/novenyek/${i.id}`)}
                                >
                                    Megtekintés
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </>
    );
};
export default Novenyek;

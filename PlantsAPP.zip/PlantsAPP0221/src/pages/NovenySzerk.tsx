import { useEffect, useState } from 'react';
import apiClient from '../api/apiClient';
import { Plant } from '../types/Plant';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const NovenySzerk = () => {
    const navigate = useNavigate();
    const [data, setData] = useState<Array<Plant>>([]);
    const [nev, setNev] = useState<string>('');
    const [evelo_e, setEvelo_e] = useState<boolean>(true);
    const [kategoria, setKategoria] = useState<string>('');
    const [ar, setAr] = useState<number>(0);
    const [content, setContent] = useState<Plant | null>(null);
    const [plant, setPlant] = useState<string>('1');

    useEffect(() => {
        apiClient.get('/plants').then((res) => {
            setData(res.data);
        });
    }, []);

    const updatePlant = async () => {
        const updatedPlant = {
            nev: nev,
            evelo_e: evelo_e,
            kategoria: kategoria,
            ar: ar,
        };
        const response = await apiClient.put(`/plants/${content?.id}`, updatedPlant);
        switch (response.status) {
            case 200:
                toast('Sikeres növény frissítés!', {
                    theme: 'colored',
                    type: 'success',
                });
                window.location.reload();
                break;
            case 404:
                toast('Nem található ilyen növény!', {
                    theme: 'colored',
                    type: 'warning',
                });
                break;
            default:
                toast('Hiba a frissítés közben!', {
                    theme: 'colored',
                    type: 'error',
                });
        }
    };

    useEffect(() => {
        const selectedId = parseInt(plant, 10);
        const selectedItem = data.find((plant) => plant.id === selectedId);
        setContent(selectedItem || null);
        if (selectedItem) {
            setNev(selectedItem.nev);
            setEvelo_e(selectedItem.evelo_e);
            setKategoria(selectedItem.kategoria);
            setAr(selectedItem.ar);
        }
    }, [plant, data]);

    return (
        <>
            <div className="navbar">
                <button className="Inaktiv" onClick={() => navigate('/novenyek')}>
                    Növények
                </button>
                <button className="Inaktiv" onClick={() => navigate('/ujnoveny')}>
                    Új növény hozzáadása
                </button>
                <button className="Aktiv">Növény szerkesztése</button>
            </div>

            <h1>Növény szerkesztése</h1>
            <select name="Novenyek" onChange={(e) => setPlant(e.target.value)}>
                <option value="">Select a plant</option>
                {data.map((i: Plant) => (
                    <option key={i.id} value={i.id.toString()}>
                        {i.nev}
                    </option>
                ))}
            </select>
            <table>
                <tbody>
                    <tr>
                        <th>Név</th>
                        <td>
                            <input
                                type="text"
                                value={nev}
                                onChange={(e) => setNev(e.target.value)}
                                placeholder="Új név"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th>Évelő-e</th>
                        <td>
                            <input
                                type="checkbox"
                                checked={evelo_e}
                                onChange={(e) => setEvelo_e(e.target.checked)}
                                placeholder="Új évelő-e"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th>Kategória</th>
                        <td>
                            <input
                                type="string"
                                value={kategoria}
                                onChange={(e) => setKategoria(e.target.value)}
                                placeholder="Új kategória"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th>Ár</th>
                        <td>
                            <input
                                type="number"
                                value={ar}
                                onChange={(e) => setAr(Number(e.target.value))}
                                placeholder="Új ár"
                            />
                        </td>
                    </tr>
                    <tr>
                        <td colSpan={2}>
                            <button className="ViewButton" onClick={updatePlant}>
                                Mentés
                            </button>
                        </td>
                    </tr>
                    <tr>
                        <td colSpan={2}>
                            <button className="BackButton" onClick={() => navigate('/novenyek')}>
                                Vissza
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </>
    );
};

export default NovenySzerk;

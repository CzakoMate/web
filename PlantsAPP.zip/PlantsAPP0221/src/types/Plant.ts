export type Plant = {
    id: number;
    nev: string;
    evelo_e: boolean;
    kategoria: string;
    ar: number;
};
